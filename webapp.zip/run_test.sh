#!/usr/bin/env bash
npm i
node migrations.js
npm run test